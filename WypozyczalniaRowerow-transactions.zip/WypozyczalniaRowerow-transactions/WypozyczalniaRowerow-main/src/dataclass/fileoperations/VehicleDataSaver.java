package dataclass.fileoperations;

import java.util.Map;

@Deprecated
public class VehicleDataSaver<K,V> implements SaveToFile<K,V>{
    @Override
    public void saveToFile(Map<K,V> data) {
    }
}
